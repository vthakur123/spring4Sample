select salary from (select salary from employee limit 2) as result order by salary desc limit 2 ;
SELECT DISTINCT(salary) FROM employee ORDER BY (salary) desc LIMIT 3,1;
SELECT concat(First_name,'-',Last_name) FROM test.employee;
select year(joining_date),month(joining_date), DAY(joining_date) from EMPLOYEE;
Select * from employee where first_name not in ('john','roy');
Select * from employee where first_name like "j%";
Select * from employee where first_name like "%o%";
Select * from EMPLOYEE where FIRST_NAME like 'j___';
Select * from EMPLOYEE where month(joining_date)=2;
select * from employee where joining_date>'2012-12-31';
Select MICROSECOND(joining_date) from EMPLOYEE;
Select FIRST_NAME from employee where Last_Name like '%\%%';
Select REPLACE(LAST_NAME,'%',' ') from employee;
select * from employee;
Select DEPARTMENT,count(first_name),sum(SALARY) Total_Salary from employee group by department order by Total_Salary desc;
select department,avg(salary) from employee group by department order by salary;
select department,min(salary) from employee group by department order by salary desc;
select year (JOINING_DATE) Join_Year,month (JOINING_DATE) Join_Month,count(*) Total_Emp from employee group by  month(JOINING_DATE);
/*
Select department,total salary with respect to a department from employee table 
where total salary greater than 800000 order by Total_Salary descending */

select department,sum(salary) Total_sal from employee group by department having Total_sal>800000 order by  Total_sal desc;

/*Select employee details from employee table if data exists in incentive table ? */

select * from employee where exists(select * from incentives);
/*  How to fetch data that are common in two query results ? */
select * from EMPLOYEE self join EMPLOYEE   where EMPLOYEE_ID < 4;
/* Get Employee ID's of those employees who didn't receive incentives without using sub query ? */

SELECT a.EMPLOYEE_ID, b.EMPLOYEE_REF_ID
FROM EMPLOYEE a LEFT JOIN INCENTIVES b
ON a.EMPLOYEE_ID = b.EMPLOYEE_REF_ID order by EMPLOYEE_ID desc limit 3;

/*Select 20 % of salary from John , 10% of Salary for Roy and for other 15 % of salary from employee table */
SELECT FIRST_NAME, CASE FIRST_NAME WHEN 'John' THEN SALARY * .2 WHEN 'Roy' THEN SALARY * .10 ELSE SALARY * .15 END "Deduced_Amount" FROM EMPLOYEE;

 SELECT case DEPARTMENT when 'Banking' then 'Bank Dept' when 'Insurance' then 'Insurance Dept' when 'Services' then 'Services Dept' end FROM EMPLOYEE;
/* Insert into employee table Last Name with " ' " (Single Quote - Special Character) */
Insert into employee (Last_name) values("'");
Select * from EMPLOYEE where lower(LAST_NAME)=upper(LAST_NAME);
/*Write a query to rank employees based on their incentives for a month */

select * from employee where exists(select Incentive_amount from incentives group by Incentive_amount);
update employee set first_name="johnh" where first_name="john";

/*Select first_name, incentive amount from employee and incentives table for those employees who have incentives */
select e.first_name, ifnull(i.incentive_amount,0)  from employee e left outer join incentives i on e.employee_id=i.Employee_ref_id  ;
select salary from employee limit 5;
select min(salary) from (select salary from employee limit 5) sal limit 1;
select distinct(salary) from employee order by salary desc limit 5;
select min(SALARY) from (select * from employee order by salary desc limit 5) a
